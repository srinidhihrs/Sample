package com.example.webservice.service;

import com.example.web_service.Customer;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

@Service
public class CustomerService {

    private static final Map<String, Customer> customers = new HashMap<String, Customer>();

    @PostConstruct
    public void initData() {
        Customer cust1 = new Customer();
        cust1.setName("Customer1");
        cust1.setAddress("India");
        cust1.setContactNo("12345678");

        Customer cust2 = new Customer();
        cust2.setName("Customer2");
        cust2.setAddress("US");
        cust2.setContactNo("47847484");

        Customer cust3 = new Customer();
        cust3.setName("Customer3");
        cust3.setAddress("UK");
        cust3.setContactNo("7937938");

        customers.put(cust1.getName(), cust1);
        customers.put(cust2.getName(), cust2);
        customers.put(cust3.getName(), cust3);
    }

    public Customer findCustomer(String name) {
        return customers.get(name);
    }
}
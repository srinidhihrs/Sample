package com.example.webservice.endpoint;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.example.web_service.GetCustomerDetails;
import com.example.web_service.GetCustomerResponse;
import com.example.webservice.service.CustomerService;

@Endpoint
public class CustomerEndpoint {
    private static final String NAMESPACE_URI = "http://example.com/web-service";
    private static final Logger logger = LoggerFactory.getLogger(CustomerEndpoint.class);
    private CustomerService customerService;

    @Autowired
    public CustomerEndpoint(CustomerService customerService) {
        this.customerService = customerService;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getCustomerDetails")
    @ResponsePayload
    public GetCustomerResponse getCustomer(@RequestPayload GetCustomerDetails request) {
    	logger.info("Customer detail is:: "+request);
        GetCustomerResponse response = new GetCustomerResponse();
        response.setCustomer(customerService.findCustomer(request.getName()));
        return response;
    }
}
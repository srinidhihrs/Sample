package com.example.webservice.service;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AccountService {

    public List<AccountDetails> getAccountDetails(){
        List<AccountDetails> accountList = new ArrayList<AccountDetails>();

        AccountDetails accountDetails1 = new AccountDetails();
        accountDetails1.setAccountId(156712);
        accountDetails1.setBalance(50000);

        AccountDetails accountDetails2 = new AccountDetails();
        accountDetails2.setAccountId(187333);
        accountDetails2.setBalance(100000);

        accountList.add(accountDetails1);
        accountList.add(accountDetails2);
        return accountList;
    }

}
package com.example.webservice.webservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

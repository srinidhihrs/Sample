/*
package com.example.gateway.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import springfox.documentation.swagger.web.SwaggerResource;
import springfox.documentation.swagger.web.SwaggerResourcesProvider;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Configuration
public class SwaggerConfig {

    @Bean
    @Primary
    public SwaggerResourcesProvider swaggerResourcesProvider(DiscoveryClient client,
                                                             @Value("${spring.application.name}") String application){
        List<String> list = Arrays.asList("security-service","gateway-service");
        return () -> client.getServices().stream()
                .filter( service -> !list.contains(service))
                .map(service -> {
                    SwaggerResource resource = new SwaggerResource();
                    resource.setName(service);
                    resource.setLocation(String.format("/%s/v3/api-docs",service));
                    return resource;
                }).collect(Collectors.toList());
    }
}*/

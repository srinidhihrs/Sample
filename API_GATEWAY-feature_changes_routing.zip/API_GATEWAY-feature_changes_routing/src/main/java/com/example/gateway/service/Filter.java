package com.example.gateway.service;

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

@Component
@Order(1)
public class Filter extends AbstractGatewayFilterFactory<Filter.Config> {

	private final WebClient.Builder webClientBuilder;
	
	public Filter( WebClient.Builder webClientBuilder){
		super(Config.class);
		this.webClientBuilder = webClientBuilder;
	}
	
	@Override
	public GatewayFilter apply(Config config) {
		return (exchange,chain) -> {
			if(!exchange.getRequest().getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
				throw new RuntimeException("Missing authorizatoin header");
			}
			String authHeader = exchange.getRequest().getHeaders().get(HttpHeaders.AUTHORIZATION).get(0);
			String [] headerParts = authHeader.split(" ");
			if(headerParts.length != 2 || !"Bearer".equals(headerParts[0])){
				throw new RuntimeException("Invalid authorization");
			}

			return webClientBuilder
					.build()
					.get()
					.uri("lb://SECURITY-SERVICE/api/validateToken?token="+headerParts[1])
					.retrieve()
					.bodyToMono(User.class)
					.map(user -> {
						exchange.getRequest().mutate().header("x-auth-user-name", user.getUsername());
						return exchange;
					}).flatMap(chain::filter);
		};
	}

	public static class Config {

	}
}

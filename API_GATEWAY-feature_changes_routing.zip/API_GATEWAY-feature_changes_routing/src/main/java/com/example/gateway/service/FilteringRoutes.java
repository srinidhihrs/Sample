package com.example.gateway.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.GatewayFilterFactory;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferFactory;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.Map;

@Service
@ConfigurationProperties(prefix = "tenants")
@Order(2)
public class FilteringRoutes implements GatewayFilterFactory<FilteringRoutes.Config> {

    @Autowired
    RestTemplate restTemplate;

    private Map<String, String> data;

    public void setData(Map<String, String> data) {
        this.data = data;
    }

    public Map<String, String> getData() {
        return data;
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            String tenantId = exchange.getRequest().getQueryParams().get("tenantId").get(0);
            ResponseEntity<Object> resp;
            ServerHttpResponse response = exchange.getResponse();

            if(data.containsKey(tenantId)){

                resp= restTemplate.getForEntity(data.get(tenantId), Object.class);
                byte[] bytes = resp.getBody().toString().getBytes(StandardCharsets.UTF_8);
                response.getHeaders().setContentType(MediaType.APPLICATION_JSON);
                DataBuffer buffer = response.bufferFactory().wrap(bytes);
                return  response.writeWith(Mono.just(buffer));

            } else {

                return chain.filter(exchange);

            }
        };
    }

    @Override
    public Class<Config> getConfigClass() {
        return Config.class;
    }

    public static class Config {
    }
}

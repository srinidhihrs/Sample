package com.commonsecurity.commonsecurity;

import java.io.IOException;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class CommonSecurityController {
	@RequestMapping("/security")
	public String test(@RequestHeader("Authflowparamter") String authflowParamter) {
		System.out.println("Header Nam--------------------------e: " + authflowParamter);
		String responseJson = null;
		if (authflowParamter.equals("ldap")) {
			String plainCreds = "loginuser:loginuser123";
			byte[] plainCredsBytes = plainCreds.getBytes();
			byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
			String base64Creds = new String(base64CredsBytes);

			HttpHeaders headers = new HttpHeaders();
			headers.add("Authorization", "Basic " + base64Creds);
			HttpEntity<String> request = new HttpEntity<String>(headers);

			ResponseEntity<String> response = new RestTemplate().exchange("http://localhost:8881/ldap",
					HttpMethod.GET, request, String.class);
			responseJson = response.getBody();

		}
		if (authflowParamter.equals("oauth")) {
			responseJson = null;

			String credentials = "testuser-user:testuser-secret";
			String encodedCredentials = new String(Base64.encodeBase64(credentials.getBytes()));
			HttpHeaders oAuthheaders = new HttpHeaders();
			oAuthheaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			oAuthheaders.add("Authorization", "Basic " + encodedCredentials);
			MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
			map.add("grant_type", "client_credentials");
			HttpEntity<MultiValueMap<String, String>> oAuthRequest = new HttpEntity<MultiValueMap<String, String>>(map,
					oAuthheaders);

			ResponseEntity<String> response = new RestTemplate().postForEntity("http://localhost:8098/oauth/token", oAuthRequest, String.class);
			ObjectMapper mapper = new ObjectMapper();
			JsonNode node = null;
			try {
				node = mapper.readTree(response.getBody());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String token = node.path("access_token").asText();

			HttpHeaders oServiceheaders = new HttpHeaders();
			oServiceheaders.add("Authorization", "Bearer " + token);
			HttpEntity<String> oServiceRequest = new HttpEntity<String>(oServiceheaders);
			ResponseEntity<String> call = new RestTemplate().postForEntity("http://localhost:8097/oauth", oServiceRequest,
					String.class);

			responseJson = call.getBody();
		}
		return responseJson;
	}
}

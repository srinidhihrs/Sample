//package com.oauthresourceserver.oauthresource;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class OauthresourceApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}

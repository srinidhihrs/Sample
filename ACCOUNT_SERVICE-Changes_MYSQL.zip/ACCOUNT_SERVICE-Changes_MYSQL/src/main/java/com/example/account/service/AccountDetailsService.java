package com.example.account.service;

import com.example.account.model.Account;
import com.example.account.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

@Service
public class AccountDetailsService {

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    AccountRepository accountRepository;


    public List<AccountDetails> getAccountDetails() {
        return Arrays.asList(restTemplate.getForEntity("http://localhost:9191/api/account-details",
                AccountDetails[].class).getBody());
    }

    public List<Account> getAccounts() {
        return accountRepository.findAll();
    }

    public Account save(Account account) {
        account.setAccountId(new Random().nextInt(10000));
        return accountRepository.save(account);
    }

    public void delete(int accountId) {
        accountRepository.deleteByAccountId(accountId);
    }
}
package com.example.security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

@Service
public class TokenValidator {
	
	@Autowired
	private JwtUtil util;
	
	@Autowired
	private UserService userService;

	public User validateToken(String token) {
		String username = util.getUsernameFromToken(token);
		if(username != null) {
			UserDetails userDetails = userService.loadUserByUsername(username);
			if(util.validateToken(token, userDetails)) {
				User user = new User();
				user.setUsername(username);
				return user;
			}
		}
		return null;
	}
}
package com.spring.springldap;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter{

    @Override
    protected void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception{
//    	System.out.println("Insidew the MGRBuilder  "+authenticationManagerBuilder.ldapAuthentication()
//                .userSearchFilter("(uid={0})")
//                .contextSource()
//                .url("ldap://localhost:8389/dc=sampleldap,dc=com")
//                .and()
//                .passwordCompare()
//                .passwordAttribute("userPassword"));
        authenticationManagerBuilder
                .ldapAuthentication()
                .userSearchFilter("(uid={0})")
                .contextSource()
                .url("ldap://localhost:8389/dc=sampleldap,dc=com")
                .and()
                .passwordCompare()
                .passwordAttribute("userPassword");

    }
    
//    @Bean
//    @Override
//    public UserDetailsService userDetailsService() {
//        return new InMemoryUserDetailsManager(
//            User.withDefaultPasswordEncoder()
//                .username("enduser")
//                .password("password")
//                .roles("USER")
//                .build());
//    }
//    
    
    
    
}
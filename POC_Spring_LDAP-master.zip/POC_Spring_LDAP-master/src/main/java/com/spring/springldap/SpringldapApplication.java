package com.spring.springldap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringldapApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringldapApplication.class, args);
	}

}

//package com.oauthauthorizationserver.oauthauthorization;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class OauthauthorizationApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}

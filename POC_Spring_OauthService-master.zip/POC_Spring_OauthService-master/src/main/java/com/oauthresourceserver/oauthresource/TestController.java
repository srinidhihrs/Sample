package com.oauthresourceserver.oauthresource;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

	@RequestMapping("/oauth")
	public String test() {
		return "From OAuthResource";
	}
}

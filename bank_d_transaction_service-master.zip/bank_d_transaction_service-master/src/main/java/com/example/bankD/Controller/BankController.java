package com.example.bankD.Controller;

import com.example.bankD.model.Transaction;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.ws.rs.QueryParam;
import java.util.Date;
import java.util.Random;
import java.util.UUID;

@RestController
@RequestMapping("/api/transaction")
public class BankController {

    static Transaction transaction = new Transaction(UUID.randomUUID().toString(),1044,"Bank D", new Date(), 24000, "INTERNET BANKING");

    @GetMapping()
    public Transaction getTransactionData(@QueryParam(value ="tenantId") Integer tenantId){
            return transaction;
    }
}

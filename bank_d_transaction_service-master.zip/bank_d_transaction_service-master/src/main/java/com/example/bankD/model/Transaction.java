package com.example.bankD.model;

import java.util.Date;

public class Transaction {

    private String transactionId;

    private int tenantId;

    private String bankName;

    private Date time;

    private long amount;

    private String paymentMode;


    public Transaction(String transactionId, int tenantId, String bankName, Date time) {
        this.transactionId = transactionId;
        this.tenantId = tenantId;
        this.bankName = bankName;
        this.time = time;
    }

    public Transaction(String transactionId, int tenantId, String bankName, Date time, long amount, String paymentMode) {
        this.transactionId = transactionId;
        this.tenantId = tenantId;
        this.bankName = bankName;
        this.time = time;
        this.amount = amount;
        this.paymentMode = paymentMode;
    }

    public void setTenantId(int tenantId) {
        this.tenantId = tenantId;
    }

    public int getTenantId() {
        return tenantId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public String getBankName() {
        return bankName;
    }

    public Date getTime() {
        return time;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public long getAmount() {
        return amount;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }
}
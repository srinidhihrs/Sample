package com.example.bankD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankDTransactionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

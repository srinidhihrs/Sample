Dynamic Routing 
1. Routing at Gateway
2. Routing using BeanFactory and @Qualifier
package com.example.transaction.model;

import java.util.Date;

public class Transaction {

    private String transactionId;

    private Integer tenantId;

    private String bankName;

    private Date time;

    public Transaction(String transactionId, Integer tenantId, String bankName, Date time) {
        this.transactionId = transactionId;
        this.tenantId = tenantId;
        this.bankName = bankName;
        this.time = time;
    }

    public void setTenantId(Integer tenantId) {
        this.tenantId = tenantId;
    }

    public Integer getTenantId() {
        return tenantId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public String getBankName() {
        return bankName;
    }

    public Date getTime() {
        return time;
    }
}
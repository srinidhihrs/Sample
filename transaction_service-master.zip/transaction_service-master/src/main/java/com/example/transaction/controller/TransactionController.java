package com.example.transaction.controller;

import com.example.transaction.model.Transaction;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/transaction")
public class TransactionController {

    static List<Transaction> transactionList = new ArrayList<>();

    static{
        transactionList.add(new Transaction(UUID.randomUUID().toString(),1040,"Bank A",new Date()));
        transactionList.add(new Transaction(UUID.randomUUID().toString(),1041,"Bank B",new Date()));
        transactionList.add(new Transaction(UUID.randomUUID().toString(),1042,"Bank C",new Date()));
        transactionList.add(new Transaction(UUID.randomUUID().toString(),200,"Bank D",new Date()));
    }

    @GetMapping()
    public Transaction getTransactionDetails(@QueryParam(value ="tenantId") Integer tenantId){
        return transactionList.stream().filter( trans -> trans.getTenantId().equals(1040)).findFirst().orElse(null);
    }
}

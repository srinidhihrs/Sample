/*
package com.example.account.model;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "bank")
public class Bank {

    @Id
    @Column(name = "bank_Code")
    private Integer bankCode;

    @Column(name = "bank_name")
    private String bankName;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "bank")
    private List<Account> accounts = new ArrayList<>();;

    public Integer getBankCode() {
        return bankCode;
    }

    public void setBankCode(Integer bankCode) {
        this.bankCode = bankCode;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public List<Account> getAccounts() {
        return accounts;
    }

    public void setAccounts(List<Account> accounts) {
        this.accounts = accounts;
    }
}
*/

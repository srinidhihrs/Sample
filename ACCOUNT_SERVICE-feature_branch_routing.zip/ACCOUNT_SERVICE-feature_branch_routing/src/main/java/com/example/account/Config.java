/*
package com.example.account;

import com.example.account.service.Content;
import com.example.account.serviceImpl.AdapterOne;
import com.example.account.serviceImpl.AdapterTwo;
import com.example.account.serviceImpl.GenericAdapter;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;


@Configuration
public class Config {

    @Bean
    @Primary
    public Content getGeneralAdapter() {
        return new GenericAdapter();
    }

    @Bean
    public Content getAdapterOne() {
        return new AdapterOne();
    }

    @Bean
    public Content getAdapterTwo() {
        return new AdapterTwo();
    }

    public Content getService(int tenantId) {
        if (tenantId == 1) {
            return getAdapterOne();
        } else if (tenantId == 2) {
            return getAdapterTwo();
        } else {
            return getGeneralAdapter();
        }
    }
}
*/

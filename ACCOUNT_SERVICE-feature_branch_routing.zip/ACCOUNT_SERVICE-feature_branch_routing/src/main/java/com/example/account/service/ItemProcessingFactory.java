package com.example.account.service;

public interface ItemProcessingFactory {

    public ItemProcessing getAdapter(String qualifier);
}

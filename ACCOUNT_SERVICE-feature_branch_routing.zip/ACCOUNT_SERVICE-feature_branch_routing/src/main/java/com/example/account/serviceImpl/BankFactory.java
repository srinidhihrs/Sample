package com.example.account.serviceImpl;

import com.example.account.service.Bank;
import org.reflections.Reflections;
import org.reflections.scanners.TypeAnnotationsScanner;
import org.reflections.util.ClasspathHelper;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Service
public class BankFactory {
    private static Map<String, Class> bankClasses = null;

    public BankFactory(){
        Reflections reflections = new Reflections(
                                        ClasspathHelper.forPackage("com.example.account"),
                                        new TypeAnnotationsScanner());
        Set<Class<?>> annotations = reflections.getTypesAnnotatedWith(Bank.class,true);
        Map<String, Class> result = new HashMap<>();
        for (Class c : annotations) {
                Bank annotation = (Bank) c.getAnnotation(Bank.class);
                result.put(annotation.value(), c);
        }
        bankClasses = result;
    }

    public Object getBankObject(String messageType) throws NoSuchMethodException, IllegalAccessException, InstantiationException, InvocationTargetException {
        Class clazz = bankClasses.get(messageType);
        if (clazz == null) {
            return new BankService();
        }
        return clazz.getConstructor().newInstance();
    }
}
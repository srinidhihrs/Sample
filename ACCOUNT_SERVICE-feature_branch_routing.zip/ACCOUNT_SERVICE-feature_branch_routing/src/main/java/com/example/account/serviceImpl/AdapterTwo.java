package com.example.account.serviceImpl;

import com.example.account.service.ItemProcessing;
import org.springframework.stereotype.Service;

@Service("itemProcessingAdapterTwo")
public class AdapterTwo implements ItemProcessing {

    @Override
    public String getAllContentDetails() {
        AdapterFour adapterFour = new AdapterFour();
        return adapterFour.getAllContentDetails();
    }

    @Override
    public String getContentDetailsSpecificToBank() {
        return "Request Not Supported";
    }
}
package com.example.account.serviceImpl;

import com.example.account.service.ItemProcessingFactory;
import com.example.account.service.ItemProcessingInterface;
import com.example.account.util.Commons;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

@Service
public class ItemProcessingImpl {


    @Autowired
    RestTemplate restTemplate;

    //TYPE 1
    @Autowired
    BankFactory bankFactory;

    //TYPE 2
    @Autowired
    BeanFactoryService beanFactory;

    @Autowired
    ItemProcessingFactory itemProcessingFactory;

    /*
        Getting details based on the incoming request(Tenant_Id) by identifying which Adapter class to be executed
     */
    public String getContentDetailsSpecificToBank(Integer tenantId) {
        String qualifier = Commons.getQualifier(tenantId);
        return itemProcessingFactory.getAdapter(qualifier).getContentDetailsSpecificToBank();
    }

    /*
        Getting details based on the incoming request(Tenant_Id) by identifying which Adapter class and Method name from the
        .yml file to be executed
     */
    public String getItemsBasedOnMethodName(Integer tenantId) throws Exception {
        Class<?> item = itemProcessingFactory.getAdapter(Commons.getQualifier(tenantId)).getClass();
        return (String) item.getMethod(Commons.getMethod().get(String.valueOf(tenantId)),null).invoke(item.newInstance());
    }

    /*
        Getting details based on the incoming request(Tenant_Id) by identifying which Microservice to be called based on
        .yml file configuration
     */
    public ResponseEntity<Object> getItemProcessingData(Integer tenantId) {
        String serviceURL = Commons.getServiceURL(tenantId);
        ResponseEntity<Object> resp = restTemplate.getForEntity(serviceURL, Object.class);
        return resp;
    }

    public String getItemProcessing(int tenantId) throws InvocationTargetException, NoSuchMethodException, IllegalAccessException, InstantiationException {

        /* Method 1*/
        ItemProcessingInterface obj1 = (ItemProcessingInterface) bankFactory.getBankObject("bankD");
        System.out.println(obj1.getItemProcessingData());

        /*Method 2*/
        ItemProcessingInterface obj2 = beanFactory.getBean(tenantId);
        return obj2.getItemProcessingData();
    }


    @Bean
    @LoadBalanced
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
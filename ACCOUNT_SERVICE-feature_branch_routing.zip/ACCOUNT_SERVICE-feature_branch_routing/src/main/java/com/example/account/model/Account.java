package com.example.account.model;

import javax.persistence.*;

@Entity
@Table(name = "accounts")
public class Account {

    @Id
    @Column(name = "account_id")
    private Integer accountId;

    @Column(name = "account_name")
    private String accountName;

    @Column(name = "account_balance")
    private Integer accountBalance;

    @Column(name = "email_id")
    private String emailId;

    /*@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "bank_code",referencedColumnName = "bankCode")
    private Bank bank;

    public Bank getBank() {
        return bank;
    }

    public void setBank(Bank bank) {
        this.bank = bank;
    }*/

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public void setAccountBalance(Integer accountBalance) {
        this.accountBalance = accountBalance;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public Integer getAccountId() {
        return accountId;
    }

    public String getAccountName() {
        return accountName;
    }

    public Integer getAccountBalance() {
        return accountBalance;
    }

    public String getEmailId() {
        return emailId;
    }
}

package com.example.account.serviceImpl;

import com.example.account.service.ItemProcessing;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service("itemProcessingAdapterThree")
public class AdapterThree implements ItemProcessing {

    @Override
    public String getAllContentDetails() {
        return "Request Not Supported";
    }

    @Override
    public String getContentDetailsSpecificToBank() {
        return "Contents from Item Processing Adapter 3";
    }
}
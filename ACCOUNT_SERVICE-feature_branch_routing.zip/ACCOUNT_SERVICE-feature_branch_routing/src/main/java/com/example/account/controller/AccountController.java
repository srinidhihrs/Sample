package com.example.account.controller;

import com.example.account.model.Account;
import com.example.account.serviceImpl.AccountDetails;
import com.example.account.serviceImpl.AccountDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.List;

@RestController
@RequestMapping("/api/accounts")
@EnableSwagger2
public class AccountController {

    @Autowired
    AccountDetailsService accountService;


    @GetMapping("/account-details")
    public List<AccountDetails> getAccountsFromMonolithicApp(){
        return accountService.getAccountDetails();
    }

    @GetMapping()
    public List<Account> getAccounts(){
        return accountService.getAccounts();
    }

    @PostMapping()
    public String saveAccount(@RequestBody Account account){
        Account acct = accountService.save(account);
        return "Account created successfully with Account No: "+acct.getAccountId();
    }

    @DeleteMapping("/{accountId}")
    public String deleteAccount(@PathVariable(value ="accountId") int accountId){
        accountService.delete(accountId);
        return String.format("Account No : %s is deleted successfully ",accountId);
    }

    @GetMapping("/{balance}")
    public List<Account> getAccountsBasedOnBalance(@PathVariable(value ="balance") int balance){
        return accountService.getAccountsBasedOnBalance(balance);
    }

    @Bean
    public Docket productApi() {
        return new Docket(DocumentationType.SWAGGER_2).select()
                .apis(RequestHandlerSelectors.basePackage("com.example.account")).build();
    }
}
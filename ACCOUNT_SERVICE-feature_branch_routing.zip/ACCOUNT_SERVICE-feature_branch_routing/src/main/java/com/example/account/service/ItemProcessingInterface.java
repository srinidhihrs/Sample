package com.example.account.service;

public interface ItemProcessingInterface<T> {

    String getItemProcessingData();
}
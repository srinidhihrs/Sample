package com.example.account.serviceImpl;

import com.example.account.service.ItemProcessing;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service("itemProcessingGenericAdapter")
public class GenericAdapter implements ItemProcessing {

    @Override
    public String getAllContentDetails() {
        return "Contents from Item Processing generic Adapter";
    }

    @Override
    public String getContentDetailsSpecificToBank() {
        return "Contents from Item Processing generic Adapter";
    }
}
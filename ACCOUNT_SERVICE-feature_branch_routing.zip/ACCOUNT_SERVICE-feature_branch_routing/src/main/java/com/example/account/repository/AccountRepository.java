package com.example.account.repository;

import com.example.account.model.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.lang.annotation.Native;
import java.util.List;

@Repository
public interface AccountRepository extends JpaRepository<Account,Integer> {

    int deleteByAccountId(int accountId);

    @Query("SELECT acc FROM Account acc WHERE acc.accountBalance >= :accountBalance")
    List<Account> getAccountsBasedOnBalance(@Param("accountBalance") int accountBalance);


}

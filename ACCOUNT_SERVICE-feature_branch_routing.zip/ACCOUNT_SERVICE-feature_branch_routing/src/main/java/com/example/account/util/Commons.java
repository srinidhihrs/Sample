package com.example.account.util;

import com.example.account.model.ItemProcessingType;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@ConfigurationProperties(prefix = "tenants")
public class Commons {

    private static Map<String, String> data;
    private static Map<String, String> url;
    private static Map<String, String> method;

    public static Map<String, String> getMethod() {
        return method;
    }

    public void setMethod(Map<String, String> method) {
        this.method = method;
    }

    public Map<String, String> getUrl() {
        return url;
    }

    public void setUrl(Map<String, String> url) {
        this.url = url;
    }

    public void setData(Map<String, String> data) {
        this.data = data;
    }

    public Map<String, String> getData() {
        return data;
    }

    public static String getQualifier(Integer tenantID){
        return data.entrySet().stream()
                            .filter( m -> m.getKey().equals(String.valueOf(tenantID)))
                            .map(Map.Entry :: getValue)
                            .findFirst()
                            .orElse(ItemProcessingType.ITEM_PROCESSING_GENERIC.toString());
    }

    public static String getServiceURL(Integer tenantID){
        return url.entrySet().stream()
                            .filter( m -> m.getKey().equals(String.valueOf(tenantID)))
                            .map(Map.Entry :: getValue).findFirst().get();
    }
}

package com.example.account.serviceImpl;

import com.example.account.service.ItemProcessingInterface;
import org.springframework.stereotype.Service;

@Service
public class BankService implements ItemProcessingInterface {

    @Override
    public String getItemProcessingData() {
       return "Item Processing Data from Generic Adapter";
    }
}
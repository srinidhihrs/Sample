package com.example.account.serviceImpl;

import com.example.account.service.Bank;
import com.example.account.service.ItemProcessingInterface;
import org.springframework.stereotype.Service;

@Bank("bankB")
@Service("400")
public class BankBService implements ItemProcessingInterface {

    @Override
    public String getItemProcessingData() {
        return "Item Processing Data from Adapter 2";
    }
}

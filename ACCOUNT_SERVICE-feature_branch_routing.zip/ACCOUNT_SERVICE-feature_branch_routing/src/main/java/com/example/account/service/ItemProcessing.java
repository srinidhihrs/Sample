package com.example.account.service;

public interface ItemProcessing {

    String getAllContentDetails();

    String getContentDetailsSpecificToBank();
}
package com.example.account.serviceImpl;

import com.example.account.service.ItemProcessing;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service("itemProcessingAdapterFour")
public class AdapterFour implements ItemProcessing {

    @Override
    public String getAllContentDetails() {
        return "Contents from Item Processing Adapter 4";
    }

    @Override
    public String getContentDetailsSpecificToBank() {
        return "Contents from Item Processing Adapter 4";
    }
}
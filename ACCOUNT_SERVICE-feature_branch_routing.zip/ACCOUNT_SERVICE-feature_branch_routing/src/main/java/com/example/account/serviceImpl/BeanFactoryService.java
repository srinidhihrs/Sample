package com.example.account.serviceImpl;

import com.example.account.service.ItemProcessingInterface;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@ConfigurationProperties(prefix = "banks")
public class BeanFactoryService {

    private List<Integer> tenantIds;

    public List<Integer> getTenantIds() {
        return tenantIds;
    }

    public void setTenantIds(List<Integer> tenantIds) {
        this.tenantIds = tenantIds;
    }

    //private static final String SERVICE_NAME_PREFIX = "bank";
    private final BeanFactory beanFactory;

    public BeanFactoryService(BeanFactory beanFactory) {
        this.beanFactory = beanFactory;
    }

    public ItemProcessingInterface getBean(int tenantId) {
        if (tenantIds.contains(tenantId)) {
            return beanFactory.getBean(String.valueOf(tenantId), ItemProcessingInterface.class);
        } else {
            return new BankService();
        }
    }
}
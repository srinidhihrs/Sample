package com.example.account.controller;

import com.example.account.service.ItemProcessingInterface;
import com.example.account.service.ItemProcessing;
import com.example.account.serviceImpl.BankFactory;
import com.example.account.serviceImpl.BeanFactoryService;
import com.example.account.serviceImpl.ItemProcessingImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.lang.reflect.InvocationTargetException;

@RestController
@RequestMapping("/api/v1")
public class ItemProcessingController {


    @Autowired
    ItemProcessingImpl itemProcessingImpl;


    @GetMapping("/item/{tenantId}")
    public String getContentDetailsSpecificToBank(@PathVariable(value = "tenantId") Integer tenantId) {
        return itemProcessingImpl.getContentDetailsSpecificToBank(tenantId);
    }

    @GetMapping("/item/specific/{tenantId}")
    public String getItemsBasedOnMethodName(@PathVariable(value = "tenantId") Integer tenantId) throws Exception {
        return itemProcessingImpl.getItemsBasedOnMethodName(tenantId);
    }

    @GetMapping("/service/item/{tenantId}")
    public ResponseEntity<Object> getItemProcessingData(@PathVariable(value = "tenantId") Integer tenantId) {
        return itemProcessingImpl.getItemProcessingData(tenantId);
    }

    @GetMapping("/{tenantId}")
    public String getItemProcessing(@PathVariable(value = "tenantId") int tenantId) throws InvocationTargetException, NoSuchMethodException, IllegalAccessException, InstantiationException {
        return itemProcessingImpl.getItemProcessing(tenantId);
    }
}
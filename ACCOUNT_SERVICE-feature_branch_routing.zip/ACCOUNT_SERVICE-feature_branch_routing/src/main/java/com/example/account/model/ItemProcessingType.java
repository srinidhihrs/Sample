package com.example.account.model;

public enum ItemProcessingType {

    ITEM_PROCESSING_ONE("itemProcessingAdapterOne"), ITEM_PROCESSING_TWO("itemProcessingAdapterTwo"),
    ITEM_PROCESSING_THREE("itemProcessingAdapterThree"), ITEM_PROCESSING_FOUR("itemProcessingAdapterFour")
    ,ITEM_PROCESSING_GENERIC("itemProcessingGenericAdapter");

    private final String value;

    ItemProcessingType(String input) {
        this.value = input;
    }

    public String getValue() {
        return this.value;
    }

    @Override
    public String toString() {
        return this.value;
    }
}

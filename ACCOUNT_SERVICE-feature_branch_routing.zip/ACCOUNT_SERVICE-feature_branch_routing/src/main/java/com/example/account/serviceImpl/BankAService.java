package com.example.account.serviceImpl;

import com.example.account.service.Bank;
import com.example.account.service.ItemProcessingInterface;
import org.springframework.stereotype.Service;

@Bank("bankA")
@Service("200")
public class BankAService implements ItemProcessingInterface {

    @Override
    public String getItemProcessingData() {
        return "Item Processing Data from Adapter 1";
    }
}
